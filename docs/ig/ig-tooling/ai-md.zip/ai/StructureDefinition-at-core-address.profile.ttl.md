# HL7® AT Core Address Profile - TTL Representation - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Address Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-address.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-address-definitions.md) 
*  [Mappings](StructureDefinition-at-core-address-mappings.md) 
*  [XML](StructureDefinition-at-core-address.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-address.profile.json.md) 
*  [TTL](#) 

## Data Type Profile: HL7ATCoreAddress - TTL Profile

| |
| :--- |
| Draft as of 2025-10-09 |

TTL representation of the at-core-address data type profile.

[Raw ttl](StructureDefinition-at-core-address.ttl) | [Download](StructureDefinition-at-core-address.ttl)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

