#  - v0.5.1

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-FolgedokumentationHI.md) 
*  [Detailed Descriptions](StructureDefinition-FolgedokumentationHI-definitions.md) 
*  [Mappings](StructureDefinition-FolgedokumentationHI-mappings.md) 
*  [XML](StructureDefinition-FolgedokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-FolgedokumentationHI.profile.json.md) 
*  [TTL](StructureDefinition-FolgedokumentationHI.profile.ttl.md) 

## Logical Model: FolgedokumentationHI - Examples

| |
| :--- |
| Draft as of 2025-10-09 |

**No examples are currently available for the Profile.**

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

