#  - v0.5.1

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-CDAPatient.md) 
*  [Detailed Descriptions](StructureDefinition-CDAPatient-definitions.md) 
*  [Mappings](StructureDefinition-CDAPatient-mappings.md) 
*  [XML](StructureDefinition-CDAPatient.profile.xml.md) 
*  [JSON](StructureDefinition-CDAPatient.profile.json.md) 
*  [TTL](StructureDefinition-CDAPatient.profile.ttl.md) 

## Logical Model: CDAPatient - Change History

| |
| :--- |
| Draft as of 2025-10-09 |

Changes in the CDAPatient logical model.

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

