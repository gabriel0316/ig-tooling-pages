# EntityCode - XML Representation - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EntityCode**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](ValueSet-v3-EntityCode.md) 
*  [XML](#) 
*  [JSON](ValueSet-v3-EntityCode.json.md) 
*  [TTL](ValueSet-v3-EntityCode.ttl.md) 

## : EntityCode - XML Representation

| |
| :--- |
| Active as of 2014-03-26 |

[Raw xml](ValueSet-v3-EntityCode.xml) | [Download](ValueSet-v3-EntityCode.xml)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

