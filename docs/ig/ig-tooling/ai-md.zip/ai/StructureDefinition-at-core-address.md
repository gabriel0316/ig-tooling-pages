# HL7® AT Core Address Profile - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Address Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-at-core-address-definitions.md) 
*  [Mappings](StructureDefinition-at-core-address-mappings.md) 
*  [XML](StructureDefinition-at-core-address.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-address.profile.json.md) 
*  [TTL](StructureDefinition-at-core-address.profile.ttl.md) 

## Data Type Profile: HL7® AT Core Address Profile 

| | |
| :--- | :--- |
| *Official URL*:https://gabriel0316.github.io/ig-tooling-pages/ig/ig-tooling/StructureDefinition/at-core-address | *Version*:0.5.1 |
| Draft as of 2025-10-09 | *Computable Name*:HL7ATCoreAddress |

 
HL7® Austria FHIR® Core Profile for address data in Austria. Note, this extension represents the common structure of address information within Austrian information systems. This extension does not restrict the documented information to Austrian adresses. Address information that does not fit into the given structure may be captured by[Address Additional Information](StructureDefinition-at-core-ext-address-additionalInformation.md). 

**Usages:**

* Use this DataType Profile: [HL7® AT Core Patient Profile](StructureDefinition-at-core-patient.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.at.fhir.gkl.ig-tooling|current/StructureDefinition/at-core-address)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Address](http://hl7.org/fhir/R4/datatypes.html#Address) 

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Address](http://hl7.org/fhir/R4/datatypes.html#Address) 

**Summary**

Prohibited: 2 elements

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-streetName.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-houseNumber.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-additionalLocator.html)
* [https://gabriel0316.github.io/ig-tooling-pages/ig/ig-tooling/StructureDefinition/at-core-ext-address-additionalInformation](StructureDefinition-at-core-ext-address-additionalInformation.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Address](http://hl7.org/fhir/R4/datatypes.html#Address) 

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Address](http://hl7.org/fhir/R4/datatypes.html#Address) 

**Summary**

Prohibited: 2 elements

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-streetName.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-houseNumber.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-additionalLocator.html)
* [https://gabriel0316.github.io/ig-tooling-pages/ig/ig-tooling/StructureDefinition/at-core-ext-address-additionalInformation](StructureDefinition-at-core-ext-address-additionalInformation.md)

 

Other representations of profile: [CSV](StructureDefinition-at-core-address.csv), [Excel](StructureDefinition-at-core-address.xlsx), [Schematron](StructureDefinition-at-core-address.sch) 

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

