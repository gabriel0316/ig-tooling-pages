# Changelog - v0.5.1

* [**Table of Contents**](toc.md)
* **Changelog**

Publication Build: This will be filled in by the publication tooling

## Changelog

* [0.5.1 (2025-10-07)](#051-2025-10-07)
* [0.4.0 (2025-02-28)](#040-2025-02-28)
* [0.3.0 (2025-01-20)](#030-2025-01-20)
* [0.2.0 (2024-04-04)](#020-2024-04-04)
* [STU 1 (2024-03-20)](#stu-1-2024-03-20)

All significant changes to this FHIR implementation guide will be documented on this page.

### 0.5.1 (2025-10-07)

* New Milestone, old canonical

### 0.4.0 (2025-02-28)

* New content

### 0.3.0 (2025-01-20)

* New content.

### 0.2.0 (2024-04-04)

* Add value set

### STU 1 (2024-03-20)

* Initial version

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

