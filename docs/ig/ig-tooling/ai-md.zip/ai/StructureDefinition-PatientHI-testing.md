# Patienten-Stammdaten - Testing - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patienten-Stammdaten**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-PatientHI.md) 
*  [Detailed Descriptions](StructureDefinition-PatientHI-definitions.md) 
*  [Mappings](StructureDefinition-PatientHI-mappings.md) 
*  [XML](StructureDefinition-PatientHI.profile.xml.md) 
*  [JSON](StructureDefinition-PatientHI.profile.json.md) 
*  [TTL](StructureDefinition-PatientHI.profile.ttl.md) 

## Logical Model: PatientHI - Testing

| |
| :--- |
| Draft as of 2025-10-09 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

