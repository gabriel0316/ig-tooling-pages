# Medizinische Datensätze - Erstdokumentation (im Rahmen der Erstabklärung erhoben/durchgeführt) - Definitions - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medizinische Datensätze - Erstdokumentation (im Rahmen der Erstabklärung erhoben/durchgeführt)**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ErstdokumentationHI.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-ErstdokumentationHI-mappings.md) 
*  [XML](StructureDefinition-ErstdokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-ErstdokumentationHI.profile.json.md) 
*  [TTL](StructureDefinition-ErstdokumentationHI.profile.ttl.md) 

## Logical Model: ErstdokumentationHI - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-09 |

Definitions for the ErstdokumentationHI logical model.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

