# Strukturdaten der beteiligten Einrichtungen/Akteure - TTL Representation - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Strukturdaten der beteiligten Einrichtungen/Akteure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-AkteurHI.md) 
*  [Detailed Descriptions](StructureDefinition-AkteurHI-definitions.md) 
*  [Mappings](StructureDefinition-AkteurHI-mappings.md) 
*  [XML](StructureDefinition-AkteurHI.profile.xml.md) 
*  [JSON](StructureDefinition-AkteurHI.profile.json.md) 
*  [TTL](#) 

## Logical Model: AkteurHI - TTL Profile

| |
| :--- |
| Draft as of 2025-10-09 |

TTL representation of the AkteurHI logical model.

[Raw ttl](StructureDefinition-AkteurHI.ttl) | [Download](StructureDefinition-AkteurHI.ttl)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

