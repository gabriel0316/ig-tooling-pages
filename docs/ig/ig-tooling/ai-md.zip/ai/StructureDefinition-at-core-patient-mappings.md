# HL7® AT Core Patient Profile - Mappings - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Patient Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-patient.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-patient-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-at-core-patient.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-patient.profile.json.md) 
*  [TTL](StructureDefinition-at-core-patient.profile.ttl.md) 

## Resource Profile: HL7ATCorePatient - Mappings

| |
| :--- |
| Draft as of 2025-10-09 |

Mappings for the at-core-patient resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

