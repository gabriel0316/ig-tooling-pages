# CDAPatient - XML Representation - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDAPatient**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-CDAPatient.md) 
*  [Detailed Descriptions](StructureDefinition-CDAPatient-definitions.md) 
*  [Mappings](StructureDefinition-CDAPatient-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-CDAPatient.profile.json.md) 
*  [TTL](StructureDefinition-CDAPatient.profile.ttl.md) 

## Logical Model: CDAPatient - XML Profile

| |
| :--- |
| Draft as of 2025-10-09 |

XML representation of the CDAPatient logical model.

[Raw xml](StructureDefinition-CDAPatient.xml) | [Download](StructureDefinition-CDAPatient.xml)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

