# HL7® AT Core Patient Profile - XML Representation - v0.5.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Patient Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-patient.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-patient-definitions.md) 
*  [Mappings](StructureDefinition-at-core-patient-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-at-core-patient.profile.json.md) 
*  [TTL](StructureDefinition-at-core-patient.profile.ttl.md) 

## Resource Profile: HL7ATCorePatient - XML Profile

| |
| :--- |
| Draft as of 2025-10-09 |

XML representation of the at-core-patient resource profile.

[Raw xml](StructureDefinition-at-core-patient.xml) | [Download](StructureDefinition-at-core-patient.xml)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.1 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-09 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

