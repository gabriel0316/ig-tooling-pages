# CDAPatient - JSON Representation - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDAPatient**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-CDAPatient.md) 
*  [Detailed Descriptions](StructureDefinition-CDAPatient-definitions.md) 
*  [Mappings](StructureDefinition-CDAPatient-mappings.md) 
*  [XML](StructureDefinition-CDAPatient.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-CDAPatient.profile.ttl.md) 

## Logical Model: CDAPatient - JSON Profile

| |
| :--- |
| Draft as of 2025-10-08 |

JSON representation of the CDAPatient logical model.

[Raw json](StructureDefinition-CDAPatient.json) | [Download](StructureDefinition-CDAPatient.json)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

