# HL7® AT Core Patient Profile - Testing - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Patient Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-patient.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-patient-definitions.md) 
*  [Mappings](StructureDefinition-at-core-patient-mappings.md) 
*  [XML](StructureDefinition-at-core-patient.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-patient.profile.json.md) 
*  [TTL](StructureDefinition-at-core-patient.profile.ttl.md) 

## Resource Profile: HL7ATCorePatient - Testing

| |
| :--- |
| Draft as of 2025-10-08 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

