#  - v0.5.2

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](ValueSet-v3-EntityCode.md) 
*  [XML](ValueSet-v3-EntityCode.xml.md) 
*  [JSON](ValueSet-v3-EntityCode.json.md) 
*  [TTL](ValueSet-v3-EntityCode.ttl.md) 

## : EntityCode - Change History

History of changes for v3-EntityCode .

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

