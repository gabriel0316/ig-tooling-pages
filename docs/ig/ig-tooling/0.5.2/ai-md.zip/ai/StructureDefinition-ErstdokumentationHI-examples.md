#  - v0.5.2

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ErstdokumentationHI.md) 
*  [Detailed Descriptions](StructureDefinition-ErstdokumentationHI-definitions.md) 
*  [Mappings](StructureDefinition-ErstdokumentationHI-mappings.md) 
*  [XML](StructureDefinition-ErstdokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-ErstdokumentationHI.profile.json.md) 
*  [TTL](StructureDefinition-ErstdokumentationHI.profile.ttl.md) 

## Logical Model: ErstdokumentationHI - Examples

| |
| :--- |
| Draft as of 2025-10-08 |

**No examples are currently available for the Profile.**

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

