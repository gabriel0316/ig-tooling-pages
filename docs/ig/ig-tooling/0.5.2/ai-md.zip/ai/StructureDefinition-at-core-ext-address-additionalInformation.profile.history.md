#  - v0.5.2

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-ext-address-additionalInformation.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-ext-address-additionalInformation-definitions.md) 
*  [Mappings](StructureDefinition-at-core-ext-address-additionalInformation-mappings.md) 
*  [XML](StructureDefinition-at-core-ext-address-additionalInformation.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-ext-address-additionalInformation.profile.json.md) 
*  [TTL](StructureDefinition-at-core-ext-address-additionalInformation.profile.ttl.md) 

## Extension: AddressAdditionalInformation - Change History

| |
| :--- |
| Draft as of 2025-10-08 |

Changes in the at-core-ext-address-additionalInformation extension.

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

