# Strukturdaten der beteiligten Einrichtungen/Akteure - JSON Representation - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Strukturdaten der beteiligten Einrichtungen/Akteure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-AkteurHI.md) 
*  [Detailed Descriptions](StructureDefinition-AkteurHI-definitions.md) 
*  [Mappings](StructureDefinition-AkteurHI-mappings.md) 
*  [XML](StructureDefinition-AkteurHI.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-AkteurHI.profile.ttl.md) 

## Logical Model: AkteurHI - JSON Profile

| |
| :--- |
| Draft as of 2025-10-08 |

JSON representation of the AkteurHI logical model.

[Raw json](StructureDefinition-AkteurHI.json) | [Download](StructureDefinition-AkteurHI.json)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

