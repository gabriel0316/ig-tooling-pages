# Table of Contents - v0.5.2

* **Table of Contents**

Publication Build: This will be filled in by the publication tooling

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 Changelog](changelog.md) |
| [3 Artifacts Summary](artifacts.md) |
| [3.1 Medizinische Datensätze - Erstdokumentation (im Rahmen der Erstabklärung erhoben/durchgeführt)](StructureDefinition-ErstdokumentationHI.md) |
| [3.2 Medizinische Datensätze - Folgedokumentation](StructureDefinition-FolgedokumentationHI.md) |
| [3.3 Patienten-Stammdaten](StructureDefinition-PatientHI.md) |
| [3.4 Strukturdaten der beteiligten Einrichtungen/Akteure](StructureDefinition-AkteurHI.md) |
| [3.5 CDAPatient](StructureDefinition-CDAPatient.md) |
| [3.6 HL7® AT Core Patient Profile](StructureDefinition-at-core-patient.md) |
| [3.7 HL7® AT Core Address Profile](StructureDefinition-at-core-address.md) |
| [3.8 Address Additional Information](StructureDefinition-at-core-ext-address-additionalInformation.md) |
| [3.9 Patient Religion](StructureDefinition-at-core-ext-patient-religion.md) |
| [3.10 EntityCode](ValueSet-v3-EntityCode.md) |

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

