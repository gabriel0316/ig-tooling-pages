# HL7® AT Core Patient Profile - Definitions - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Patient Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-patient.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-at-core-patient-mappings.md) 
*  [XML](StructureDefinition-at-core-patient.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-patient.profile.json.md) 
*  [TTL](StructureDefinition-at-core-patient.profile.ttl.md) 

## Resource Profile: HL7ATCorePatient - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-08 |

Definitions for the at-core-patient resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

