# Medizinische Datensätze - Folgedokumentation - Testing - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medizinische Datensätze - Folgedokumentation**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-FolgedokumentationHI.md) 
*  [Detailed Descriptions](StructureDefinition-FolgedokumentationHI-definitions.md) 
*  [Mappings](StructureDefinition-FolgedokumentationHI-mappings.md) 
*  [XML](StructureDefinition-FolgedokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-FolgedokumentationHI.profile.json.md) 
*  [TTL](StructureDefinition-FolgedokumentationHI.profile.ttl.md) 

## Logical Model: FolgedokumentationHI - Testing

| |
| :--- |
| Draft as of 2025-10-08 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

