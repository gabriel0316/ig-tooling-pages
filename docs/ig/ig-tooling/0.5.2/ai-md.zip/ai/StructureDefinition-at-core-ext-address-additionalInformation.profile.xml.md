# Address Additional Information - XML Representation - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Address Additional Information**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-ext-address-additionalInformation.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-ext-address-additionalInformation-definitions.md) 
*  [Mappings](StructureDefinition-at-core-ext-address-additionalInformation-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-at-core-ext-address-additionalInformation.profile.json.md) 
*  [TTL](StructureDefinition-at-core-ext-address-additionalInformation.profile.ttl.md) 

## Extension: AddressAdditionalInformation - XML Profile

| |
| :--- |
| Draft as of 2025-10-08 |

XML representation of the at-core-ext-address-additionalInformation extension.

[Raw xml](StructureDefinition-at-core-ext-address-additionalInformation.xml) | [Download](StructureDefinition-at-core-ext-address-additionalInformation.xml)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

