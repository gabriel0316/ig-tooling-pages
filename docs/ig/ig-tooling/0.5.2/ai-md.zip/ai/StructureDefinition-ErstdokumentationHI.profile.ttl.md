# Medizinische Datensätze - Erstdokumentation (im Rahmen der Erstabklärung erhoben/durchgeführt) - TTL Representation - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medizinische Datensätze - Erstdokumentation (im Rahmen der Erstabklärung erhoben/durchgeführt)**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-ErstdokumentationHI.md) 
*  [Detailed Descriptions](StructureDefinition-ErstdokumentationHI-definitions.md) 
*  [Mappings](StructureDefinition-ErstdokumentationHI-mappings.md) 
*  [XML](StructureDefinition-ErstdokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-ErstdokumentationHI.profile.json.md) 
*  [TTL](#) 

## Logical Model: ErstdokumentationHI - TTL Profile

| |
| :--- |
| Draft as of 2025-10-08 |

TTL representation of the ErstdokumentationHI logical model.

[Raw ttl](StructureDefinition-ErstdokumentationHI.ttl) | [Download](StructureDefinition-ErstdokumentationHI.ttl)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

