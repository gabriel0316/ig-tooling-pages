#  - v0.5.2

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-ext-patient-religion.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-ext-patient-religion-definitions.md) 
*  [Mappings](StructureDefinition-at-core-ext-patient-religion-mappings.md) 
*  [XML](StructureDefinition-at-core-ext-patient-religion.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-ext-patient-religion.profile.json.md) 
*  [TTL](StructureDefinition-at-core-ext-patient-religion.profile.ttl.md) 

## Extension: PatientReligion - Change History

| |
| :--- |
| Draft as of 2025-10-08 |

Changes in the at-core-ext-patient-religion extension.

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

