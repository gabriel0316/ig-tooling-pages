# Medizinische Datensätze - Folgedokumentation - TTL Representation - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medizinische Datensätze - Folgedokumentation**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-FolgedokumentationHI.md) 
*  [Detailed Descriptions](StructureDefinition-FolgedokumentationHI-definitions.md) 
*  [Mappings](StructureDefinition-FolgedokumentationHI-mappings.md) 
*  [XML](StructureDefinition-FolgedokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-FolgedokumentationHI.profile.json.md) 
*  [TTL](#) 

## Logical Model: FolgedokumentationHI - TTL Profile

| |
| :--- |
| Draft as of 2025-10-08 |

TTL representation of the FolgedokumentationHI logical model.

[Raw ttl](StructureDefinition-FolgedokumentationHI.ttl) | [Download](StructureDefinition-FolgedokumentationHI.ttl)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

