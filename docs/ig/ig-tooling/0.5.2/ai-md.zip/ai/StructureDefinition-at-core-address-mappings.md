# HL7® AT Core Address Profile - Mappings - v0.5.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Address Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-address.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-address-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-at-core-address.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-address.profile.json.md) 
*  [TTL](StructureDefinition-at-core-address.profile.ttl.md) 

## Data Type Profile: HL7ATCoreAddress - Mappings

| |
| :--- |
| Draft as of 2025-10-08 |

Mappings for the at-core-address data type profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

