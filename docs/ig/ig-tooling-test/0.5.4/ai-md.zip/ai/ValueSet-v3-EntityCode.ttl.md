# EntityCode - TTL Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EntityCode**

Publication Build: This will be filled in by the publication tooling

*  [Narrative Content](ValueSet-v3-EntityCode.md) 
*  [XML](ValueSet-v3-EntityCode.xml.md) 
*  [JSON](ValueSet-v3-EntityCode.json.md) 
*  [TTL](#) 

## : EntityCode - TTL Representation

| |
| :--- |
| Active as of 2014-03-26 |

[Raw ttl](ValueSet-v3-EntityCode.ttl) | [Download](ValueSet-v3-EntityCode.ttl)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

