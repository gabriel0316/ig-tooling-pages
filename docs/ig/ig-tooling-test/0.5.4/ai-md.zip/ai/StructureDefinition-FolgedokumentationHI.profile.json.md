# Medizinische Datensätze - Folgedokumentation - JSON Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medizinische Datensätze - Folgedokumentation**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-FolgedokumentationHI.md) 
*  [Detailed Descriptions](StructureDefinition-FolgedokumentationHI-definitions.md) 
*  [Mappings](StructureDefinition-FolgedokumentationHI-mappings.md) 
*  [XML](StructureDefinition-FolgedokumentationHI.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-FolgedokumentationHI.profile.ttl.md) 

## Logical Model: FolgedokumentationHI - JSON Profile

| |
| :--- |
| Draft as of 2025-10-10 |

JSON representation of the FolgedokumentationHI logical model.

[Raw json](StructureDefinition-FolgedokumentationHI.json) | [Download](StructureDefinition-FolgedokumentationHI.json)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

