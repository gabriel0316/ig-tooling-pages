# Address Additional Information - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Address Additional Information**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-at-core-ext-address-additionalInformation-definitions.md) 
*  [Mappings](StructureDefinition-at-core-ext-address-additionalInformation-mappings.md) 
*  [XML](StructureDefinition-at-core-ext-address-additionalInformation.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-ext-address-additionalInformation.profile.json.md) 
*  [TTL](StructureDefinition-at-core-ext-address-additionalInformation.profile.ttl.md) 

## Extension: Address Additional Information 

| | |
| :--- | :--- |
| *Official URL*:https://gabriel0316.github.io/ig-tooling-pages/ig/ig-tooling-test/StructureDefinition/at-core-ext-address-additionalInformation | *Version*:0.5.4 |
| Draft as of 2025-10-10 | *Computable Name*:AddressAdditionalInformation |

HL7® Austria FHIR® Core Extension for the additional information part of the Austrian address.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [HL7® AT Core Address Profile](StructureDefinition-at-core-address.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.at.fhir.gkl.ig-tooling|current/StructureDefinition/at-core-ext-address-additionalInformation)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: HL7® Austria FHIR® Core Extension for the additional information part of the Austrian address.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type string: HL7® Austria FHIR® Core Extension for the additional information part of the Austrian address.

 

Other representations of profile: [CSV](StructureDefinition-at-core-ext-address-additionalInformation.csv), [Excel](StructureDefinition-at-core-ext-address-additionalInformation.xlsx), [Schematron](StructureDefinition-at-core-ext-address-additionalInformation.sch) 

#### Constraints

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

