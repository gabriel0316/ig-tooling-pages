# Patienten-Stammdaten - XML Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patienten-Stammdaten**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-PatientHI.md) 
*  [Detailed Descriptions](StructureDefinition-PatientHI-definitions.md) 
*  [Mappings](StructureDefinition-PatientHI-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-PatientHI.profile.json.md) 
*  [TTL](StructureDefinition-PatientHI.profile.ttl.md) 

## Logical Model: PatientHI - XML Profile

| |
| :--- |
| Draft as of 2025-10-10 |

XML representation of the PatientHI logical model.

[Raw xml](StructureDefinition-PatientHI.xml) | [Download](StructureDefinition-PatientHI.xml)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

