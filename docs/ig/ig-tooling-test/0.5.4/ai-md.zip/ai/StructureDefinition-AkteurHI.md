# Strukturdaten der beteiligten Einrichtungen/Akteure - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Strukturdaten der beteiligten Einrichtungen/Akteure**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-AkteurHI-definitions.md) 
*  [Mappings](StructureDefinition-AkteurHI-mappings.md) 
*  [XML](StructureDefinition-AkteurHI.profile.xml.md) 
*  [JSON](StructureDefinition-AkteurHI.profile.json.md) 
*  [TTL](StructureDefinition-AkteurHI.profile.ttl.md) 

## Logical Model: Strukturdaten der beteiligten Einrichtungen/Akteure 

| | |
| :--- | :--- |
| *Official URL*:https://gabriel0316.github.io/ig-tooling-pages/ig/ig-tooling-test/StructureDefinition/AkteurHI | *Version*:0.5.4 |
| Draft as of 2025-10-10 | *Computable Name*:AkteurHI |

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.at.fhir.gkl.ig-tooling|current/StructureDefinition/AkteurHI)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(16 nested mandatory elements)

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(16 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-AkteurHI.csv), [Excel](StructureDefinition-AkteurHI.xlsx) 

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

