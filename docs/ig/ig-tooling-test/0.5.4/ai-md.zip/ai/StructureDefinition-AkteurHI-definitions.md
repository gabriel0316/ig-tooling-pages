# Strukturdaten der beteiligten Einrichtungen/Akteure - Definitions - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Strukturdaten der beteiligten Einrichtungen/Akteure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-AkteurHI.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-AkteurHI-mappings.md) 
*  [XML](StructureDefinition-AkteurHI.profile.xml.md) 
*  [JSON](StructureDefinition-AkteurHI.profile.json.md) 
*  [TTL](StructureDefinition-AkteurHI.profile.ttl.md) 

## Logical Model: AkteurHI - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-10 |

Definitions for the AkteurHI logical model.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

