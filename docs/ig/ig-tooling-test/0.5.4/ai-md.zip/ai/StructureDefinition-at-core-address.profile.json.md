# HL7® AT Core Address Profile - JSON Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Core Address Profile**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-address.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-address-definitions.md) 
*  [Mappings](StructureDefinition-at-core-address-mappings.md) 
*  [XML](StructureDefinition-at-core-address.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-at-core-address.profile.ttl.md) 

## Data Type Profile: HL7ATCoreAddress - JSON Profile

| |
| :--- |
| Draft as of 2025-10-10 |

JSON representation of the at-core-address data type profile.

[Raw json](StructureDefinition-at-core-address.json) | [Download](StructureDefinition-at-core-address.json)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

