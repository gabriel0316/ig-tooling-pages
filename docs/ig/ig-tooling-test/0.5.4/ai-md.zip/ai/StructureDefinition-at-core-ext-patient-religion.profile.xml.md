# Patient Religion - XML Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Religion**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-ext-patient-religion.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-ext-patient-religion-definitions.md) 
*  [Mappings](StructureDefinition-at-core-ext-patient-religion-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-at-core-ext-patient-religion.profile.json.md) 
*  [TTL](StructureDefinition-at-core-ext-patient-religion.profile.ttl.md) 

## Extension: PatientReligion - XML Profile

| |
| :--- |
| Draft as of 2025-10-10 |

XML representation of the at-core-ext-patient-religion extension.

[Raw xml](StructureDefinition-at-core-ext-patient-religion.xml) | [Download](StructureDefinition-at-core-ext-patient-religion.xml)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

