# Patient Religion - TTL Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Religion**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-ext-patient-religion.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-ext-patient-religion-definitions.md) 
*  [Mappings](StructureDefinition-at-core-ext-patient-religion-mappings.md) 
*  [XML](StructureDefinition-at-core-ext-patient-religion.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-ext-patient-religion.profile.json.md) 
*  [TTL](#) 

## Extension: PatientReligion - TTL Profile

| |
| :--- |
| Draft as of 2025-10-10 |

TTL representation of the at-core-ext-patient-religion extension.

[Raw ttl](StructureDefinition-at-core-ext-patient-religion.ttl) | [Download](StructureDefinition-at-core-ext-patient-religion.ttl)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

