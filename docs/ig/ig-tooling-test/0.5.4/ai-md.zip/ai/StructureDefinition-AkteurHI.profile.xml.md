# Strukturdaten der beteiligten Einrichtungen/Akteure - XML Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Strukturdaten der beteiligten Einrichtungen/Akteure**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-AkteurHI.md) 
*  [Detailed Descriptions](StructureDefinition-AkteurHI-definitions.md) 
*  [Mappings](StructureDefinition-AkteurHI-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-AkteurHI.profile.json.md) 
*  [TTL](StructureDefinition-AkteurHI.profile.ttl.md) 

## Logical Model: AkteurHI - XML Profile

| |
| :--- |
| Draft as of 2025-10-10 |

XML representation of the AkteurHI logical model.

[Raw xml](StructureDefinition-AkteurHI.xml) | [Download](StructureDefinition-AkteurHI.xml)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

