#  - v0.5.4

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-AkteurHI.md) 
*  [Detailed Descriptions](StructureDefinition-AkteurHI-definitions.md) 
*  [Mappings](StructureDefinition-AkteurHI-mappings.md) 
*  [XML](StructureDefinition-AkteurHI.profile.xml.md) 
*  [JSON](StructureDefinition-AkteurHI.profile.json.md) 
*  [TTL](StructureDefinition-AkteurHI.profile.ttl.md) 

## Logical Model: AkteurHI - Examples

| |
| :--- |
| Draft as of 2025-10-10 |

**No examples are currently available for the Profile.**

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

