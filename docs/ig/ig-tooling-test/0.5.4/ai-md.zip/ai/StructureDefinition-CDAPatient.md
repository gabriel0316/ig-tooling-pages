# CDAPatient - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDAPatient**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-CDAPatient-definitions.md) 
*  [Mappings](StructureDefinition-CDAPatient-mappings.md) 
*  [XML](StructureDefinition-CDAPatient.profile.xml.md) 
*  [JSON](StructureDefinition-CDAPatient.profile.json.md) 
*  [TTL](StructureDefinition-CDAPatient.profile.ttl.md) 

## Logical Model: CDAPatient 

| | |
| :--- | :--- |
| *Official URL*:https://gabriel0316.github.io/ig-tooling-pages/ig/ig-tooling-test/StructureDefinition/CDAPatient | *Version*:0.5.4 |
| Draft as of 2025-10-10 | *Computable Name*:CDAPatient |

 
Some Patient 

**Usages:**

* This Logical Model Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.at.fhir.gkl.ig-tooling|current/StructureDefinition/CDAPatient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [Patient](http://hl7.org/cda/stds/core/2.0.0-sd-snapshot1/StructureDefinition-Patient.html) 

#### Terminology Bindings

This structure is derived from [Patient](http://hl7.org/cda/stds/core/2.0.0-sd-snapshot1/StructureDefinition-Patient.html) 

**Summary**

Mandatory: 1 element

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [Patient](http://hl7.org/cda/stds/core/2.0.0-sd-snapshot1/StructureDefinition-Patient.html) 

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [Patient](http://hl7.org/cda/stds/core/2.0.0-sd-snapshot1/StructureDefinition-Patient.html) 

**Summary**

Mandatory: 1 element

 

Other representations of profile: [CSV](StructureDefinition-CDAPatient.csv), [Excel](StructureDefinition-CDAPatient.xlsx) 

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

