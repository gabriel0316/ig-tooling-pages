# Address Additional Information - Definitions - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Address Additional Information**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-ext-address-additionalInformation.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-at-core-ext-address-additionalInformation-mappings.md) 
*  [XML](StructureDefinition-at-core-ext-address-additionalInformation.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-ext-address-additionalInformation.profile.json.md) 
*  [TTL](StructureDefinition-at-core-ext-address-additionalInformation.profile.ttl.md) 

## Extension: AddressAdditionalInformation - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-10 |

Definitions for the at-core-ext-address-additionalInformation extension.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

