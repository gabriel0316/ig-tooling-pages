# CDAPatient - Definitions - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CDAPatient**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-CDAPatient.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-CDAPatient-mappings.md) 
*  [XML](StructureDefinition-CDAPatient.profile.xml.md) 
*  [JSON](StructureDefinition-CDAPatient.profile.json.md) 
*  [TTL](StructureDefinition-CDAPatient.profile.ttl.md) 

## Logical Model: CDAPatient - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-10 |

Definitions for the CDAPatient logical model.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

