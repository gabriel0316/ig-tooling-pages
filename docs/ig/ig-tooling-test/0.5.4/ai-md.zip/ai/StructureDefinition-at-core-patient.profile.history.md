#  - v0.5.4

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-patient.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-patient-definitions.md) 
*  [Mappings](StructureDefinition-at-core-patient-mappings.md) 
*  [XML](StructureDefinition-at-core-patient.profile.xml.md) 
*  [JSON](StructureDefinition-at-core-patient.profile.json.md) 
*  [TTL](StructureDefinition-at-core-patient.profile.ttl.md) 

## Resource Profile: HL7ATCorePatient - Change History

| |
| :--- |
| Draft as of 2025-10-10 |

Changes in the at-core-patient resource profile.

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

