# Address Additional Information - JSON Representation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Address Additional Information**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-at-core-ext-address-additionalInformation.md) 
*  [Detailed Descriptions](StructureDefinition-at-core-ext-address-additionalInformation-definitions.md) 
*  [Mappings](StructureDefinition-at-core-ext-address-additionalInformation-mappings.md) 
*  [XML](StructureDefinition-at-core-ext-address-additionalInformation.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-at-core-ext-address-additionalInformation.profile.ttl.md) 

## Extension: AddressAdditionalInformation - JSON Profile

| |
| :--- |
| Draft as of 2025-10-10 |

JSON representation of the at-core-ext-address-additionalInformation extension.

[Raw json](StructureDefinition-at-core-ext-address-additionalInformation.json) | [Download](StructureDefinition-at-core-ext-address-additionalInformation.json)

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

