# Medizinische Datensätze - Folgedokumentation - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medizinische Datensätze - Folgedokumentation**

Publication Build: This will be filled in by the publication tooling

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-FolgedokumentationHI-definitions.md) 
*  [Mappings](StructureDefinition-FolgedokumentationHI-mappings.md) 
*  [XML](StructureDefinition-FolgedokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-FolgedokumentationHI.profile.json.md) 
*  [TTL](StructureDefinition-FolgedokumentationHI.profile.ttl.md) 

## Logical Model: Medizinische Datensätze - Folgedokumentation 

| | |
| :--- | :--- |
| *Official URL*:https://gabriel0316.github.io/ig-tooling-pages/ig/ig-tooling-test/StructureDefinition/FolgedokumentationHI | *Version*:0.5.4 |
| Draft as of 2025-10-10 | *Computable Name*:FolgedokumentationHI |

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.at.fhir.gkl.ig-tooling|current/StructureDefinition/FolgedokumentationHI)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(54 nested mandatory elements)

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(54 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-FolgedokumentationHI.csv), [Excel](StructureDefinition-FolgedokumentationHI.xlsx) 

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

