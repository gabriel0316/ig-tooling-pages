# Medizinische Datensätze - Folgedokumentation - Mappings - v0.5.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medizinische Datensätze - Folgedokumentation**

Publication Build: This will be filled in by the publication tooling

*  [Content](StructureDefinition-FolgedokumentationHI.md) 
*  [Detailed Descriptions](StructureDefinition-FolgedokumentationHI-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-FolgedokumentationHI.profile.xml.md) 
*  [JSON](StructureDefinition-FolgedokumentationHI.profile.json.md) 
*  [TTL](StructureDefinition-FolgedokumentationHI.profile.ttl.md) 

## Logical Model: FolgedokumentationHI - Mappings

| |
| :--- |
| Draft as of 2025-10-10 |

Mappings for the FolgedokumentationHI logical model.

No Mappings

 IG © 2023+ . Package hl7.at.fhir.gkl.ig-tooling#0.5.4 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-10 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

